using SMS.BL.DTOs.LaptopDTOs;
using SMS.BL.DTOs.StudentDTOs;
using SMS.BL.DTOs.TeacherDTOs;
using SMS.DAL.Models;
using SMS.DAL.Repos.StudentRepo;
using SMS.DAL.Repos.TeacherRepo;
using System.Collections.Generic;
using System.Linq;

namespace SMS.BL.Services.StudentService
{
    public class StudentService : IStudentService
    {
        private readonly IStudentRepo _studentRepo;
        private readonly ITeacherRepo _teacherRepo;

        public StudentService(IStudentRepo studentRepo, ITeacherRepo teacherRepo)
        {
            _studentRepo = studentRepo;
            _teacherRepo = teacherRepo;
        }

        public StudentReadDTO Add(StudentWriteDTO dto)
        {
            var student = new Student
            {
                Name = dto.Name,
                Email = dto.Email
            };

            if (!string.IsNullOrWhiteSpace(dto.LaptopModel))
            {
                student.Laptop = new Laptop
                {
                    Model = dto.LaptopModel.Trim()
                };
            }

            if (dto.TeacherIds != null && dto.TeacherIds.Any())
            {
                var teachers = _teacherRepo.GetByIds(dto.TeacherIds);
                foreach (var teacher in teachers)
                {
                    student.Teachers.Add(teacher);
                }
            }

            _studentRepo.Add(student);
            _studentRepo.SaveChanges();

            return MapToReadDTO(student);
        }

        public StudentReadDTO? GetById(int id)
        {
            var student = _studentRepo.GetById(id);
            if (student == null) return null;

            return MapToReadDTO(student);
        }

        public IEnumerable<StudentReadDTO> GetAll()
        {
            return _studentRepo.GetAll().Select(MapToReadDTO).ToList();
        }

        public bool Update(int id, StudentUpdateDTO dto)
        {
            var student = _studentRepo.GetById(id);
            if (student == null) return false;

            student.Name = dto.Name;
            student.Email = dto.Email;

            if (!string.IsNullOrWhiteSpace(dto.LaptopModel))
            {
                if (student.Laptop != null)
                {
                    student.Laptop.Model = dto.LaptopModel.Trim();
                }
                else
                {
                    student.Laptop = new Laptop
                    {
                        Model = dto.LaptopModel.Trim()
                    };
                }
            }
            else if (dto.LaptopModel != null && string.IsNullOrWhiteSpace(dto.LaptopModel))
            {
                student.Laptop = null;
                student.LaptopId = null;
            }

            if (dto.TeacherIds != null)
            {
                student.Teachers.Clear();
                if (dto.TeacherIds.Any())
                {
                    var teachers = _teacherRepo.GetByIds(dto.TeacherIds);
                    foreach (var teacher in teachers)
                    {
                        student.Teachers.Add(teacher);
                    }
                }
            }

            _studentRepo.Update(student);
            _studentRepo.SaveChanges();
            return true;
        }

        public bool Delete(int id)
        {
            var student = _studentRepo.GetById(id);
            if (student == null) return false;

            _studentRepo.Delete(student);
            _studentRepo.SaveChanges();
            return true;
        }

        private static StudentReadDTO MapToReadDTO(Student s)
        {
            return new StudentReadDTO
            {
                Id = s.Id,
                Name = s.Name,
                Email = s.Email,
                Laptop = s.Laptop == null ? null : new LaptopReadDTO
                {
                    Id = s.Laptop.Id,
                    Model = s.Laptop.Model
                },
                Teachers = s.Teachers?.Select(t => new TeacherReadDTO
                {
                    Id = t.Id,
                    Name = t.Name,
                    Email = t.Email,
                    Phone = t.Phone,
                    SubjectId = t.SubjectId,
                    SubjectName = t.Subject?.Name
                }).ToList() ?? new List<TeacherReadDTO>()
            };
        }
    }
}
