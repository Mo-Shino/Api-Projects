using Microsoft.AspNetCore.Mvc;
using HMS.BL.DTOs.DepartmentDTOs;
using HMS.BL.Services.DepartmentService;

namespace HMS.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Route("api/departments")]
    public class DepartmentController : ControllerBase
    {
        private readonly IDepartmentService _departmentService;

        public DepartmentController(IDepartmentService departmentService)
        {
            _departmentService = departmentService;
        }

        [HttpPost]
        public IActionResult Add([FromBody] DepartmentWriteDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = _departmentService.Add(dto);
            return Ok(result);
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var departments = _departmentService.GetAll();
            return Ok(departments);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var department = _departmentService.GetById(id);
            if (department == null)
            {
                return NotFound($"Department with Id {id} not found.");
            }

            return Ok(department);
        }
    }
}
