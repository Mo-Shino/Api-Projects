using SMS.BL.DTOs.TeacherDTOs;
using SMS.DAL.Models;
using SMS.DAL.Repos.SubjectRepo;
using SMS.DAL.Repos.TeacherRepo;
using System.Collections.Generic;
using System.Linq;

namespace SMS.BL.Services.TeacherService
{
    public class TeacherService : ITeacherService
    {
        private readonly ITeacherRepo _teacherRepo;
        private readonly ISubjectRepo _subjectRepo;

        public TeacherService(ITeacherRepo teacherRepo, ISubjectRepo subjectRepo)
        {
            _teacherRepo = teacherRepo;
            _subjectRepo = subjectRepo;
        }

        public TeacherReadDTO? Add(TeacherWriteDTO dto)
        {
            var subject = _subjectRepo.GetById(dto.SubjectId);
            if (subject == null)
            {
                return null;
            }

            var teacher = new Teacher
            {
                Name = dto.Name,
                Email = dto.Email,
                Phone = dto.Phone,
                SubjectId = dto.SubjectId
            };

            _teacherRepo.Add(teacher);
            _teacherRepo.SaveChanges();

            return new TeacherReadDTO
            {
                Id = teacher.Id,
                Name = teacher.Name,
                Email = teacher.Email,
                Phone = teacher.Phone,
                SubjectId = teacher.SubjectId,
                SubjectName = subject.Name
            };
        }

        public TeacherReadDTO? GetById(int id)
        {
            var teacher = _teacherRepo.GetById(id);
            if (teacher == null) return null;

            return new TeacherReadDTO
            {
                Id = teacher.Id,
                Name = teacher.Name,
                Email = teacher.Email,
                Phone = teacher.Phone,
                SubjectId = teacher.SubjectId,
                SubjectName = teacher.Subject?.Name
            };
        }

        public IEnumerable<TeacherReadDTO> GetAll()
        {
            return _teacherRepo.GetAll().Select(t => new TeacherReadDTO
            {
                Id = t.Id,
                Name = t.Name,
                Email = t.Email,
                Phone = t.Phone,
                SubjectId = t.SubjectId,
                SubjectName = t.Subject?.Name
            }).ToList();
        }
    }
}
