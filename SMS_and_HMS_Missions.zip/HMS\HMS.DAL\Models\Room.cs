using System.ComponentModel.DataAnnotations;

namespace HMS.DAL.Models
{
    public class Room
    {
        public int Id { get; set; }

        [Required]
        public string RoomNumber { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Type { get; set; } = string.Empty;

        public Guest? Guest { get; set; }
    }
}
