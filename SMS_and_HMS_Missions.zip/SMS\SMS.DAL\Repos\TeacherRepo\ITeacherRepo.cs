using SMS.DAL.Models;
using System.Collections.Generic;

namespace SMS.DAL.Repos.TeacherRepo
{
    public interface ITeacherRepo
    {
        void Add(Teacher teacher);
        Teacher? GetById(int id);
        IEnumerable<Teacher> GetAll();
        IEnumerable<Teacher> GetByIds(IEnumerable<int> ids);
        bool SaveChanges();
    }
}
