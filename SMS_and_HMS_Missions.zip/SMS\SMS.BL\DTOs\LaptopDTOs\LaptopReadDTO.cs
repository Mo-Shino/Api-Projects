namespace SMS.BL.DTOs.LaptopDTOs
{
    public class LaptopReadDTO
    {
        public int Id { get; set; }
        public string Model { get; set; } = string.Empty;
    }
}
