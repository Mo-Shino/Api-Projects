using Microsoft.EntityFrameworkCore;
using SMS.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.DAL.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Student> Students { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Laptop> Laptops { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // 1. One-to-One: Student <-> Laptop (Optional)
            modelBuilder.Entity<Student>()
                .HasOne(s => s.Laptop)
                .WithOne(l => l.Student)
                .HasForeignKey<Student>(s => s.LaptopId)
                .IsRequired(false)
                .OnDelete(DeleteBehavior.SetNull);

            // 2. One-to-Many: Subject <-> Teachers
            modelBuilder.Entity<Teacher>()
                .HasOne(t => t.Subject)
                .WithMany(s => s.Teachers)
                .HasForeignKey(t => t.SubjectId)
                .OnDelete(DeleteBehavior.Restrict);

            // 3. Many-to-Many: Student <-> Teachers
            modelBuilder.Entity<Student>()
                .HasMany(s => s.Teachers)
                .WithMany(t => t.Students);
        }
    }
}
