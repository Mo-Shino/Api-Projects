using Microsoft.EntityFrameworkCore;
using SMS.BL.Services.StudentService;
using SMS.BL.Services.SubjectService;
using SMS.BL.Services.TeacherService;
using SMS.DAL.Data;
using SMS.DAL.Repos.StudentRepo;
using SMS.DAL.Repos.SubjectRepo;
using SMS.DAL.Repos.TeacherRepo;

namespace SMS.API
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add DbContext
            builder.Services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("conn")));

            // Register Repositories
            builder.Services.AddScoped<ISubjectRepo, SubjectRepo>();
            builder.Services.AddScoped<ITeacherRepo, TeacherRepo>();
            builder.Services.AddScoped<IStudentRepo, StudentRepo>();

            // Register Business Services
            builder.Services.AddScoped<ISubjectService, SubjectService>();
            builder.Services.AddScoped<ITeacherService, TeacherService>();
            builder.Services.AddScoped<IStudentService, StudentService>();

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}
