using SMS.DAL.Data;
using SMS.DAL.Models;
using System.Collections.Generic;
using System.Linq;

namespace SMS.DAL.Repos.SubjectRepo
{
    public class SubjectRepo : ISubjectRepo
    {
        private readonly AppDbContext _context;

        public SubjectRepo(AppDbContext context)
        {
            _context = context;
        }

        public void Add(Subject subject)
        {
            _context.Subjects.Add(subject);
        }

        public Subject? GetById(int id)
        {
            return _context.Subjects.FirstOrDefault(s => s.Id == id);
        }

        public IEnumerable<Subject> GetAll()
        {
            return _context.Subjects.ToList();
        }

        public bool SaveChanges()
        {
            return _context.SaveChanges() > 0;
        }
    }
}
