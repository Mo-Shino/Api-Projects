using Microsoft.AspNetCore.Mvc;
using HMS.BL.DTOs.StaffDTOs;
using HMS.BL.Services.StaffService;

namespace HMS.API.Controllers
{
    [ApiController]
    [Route("api/staff")]
    public class StaffController : ControllerBase
    {
        private readonly IStaffService _staffService;

        public StaffController(IStaffService staffService)
        {
            _staffService = staffService;
        }

        [HttpPost]
        public IActionResult Add([FromBody] StaffWriteDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = _staffService.Add(dto);
            if (result == null)
            {
                return BadRequest($"Department with Id {dto.DepartmentId} does not exist.");
            }

            return Ok(result);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var staff = _staffService.GetById(id);
            if (staff == null)
            {
                return NotFound($"Staff member with Id {id} not found.");
            }

            return Ok(staff);
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var staffList = _staffService.GetAll();
            return Ok(staffList);
        }
    }
}
