using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HMS.DAL.Models
{
    public class Department
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; } = string.Empty;

        public string? Description { get; set; }

        public ICollection<Staff> StaffMembers { get; set; } = new List<Staff>();
    }
}
