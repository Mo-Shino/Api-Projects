using SMS.BL.DTOs.LaptopDTOs;
using SMS.BL.DTOs.TeacherDTOs;
using System.Collections.Generic;

namespace SMS.BL.DTOs.StudentDTOs
{
    public class StudentReadDTO
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public LaptopReadDTO? Laptop { get; set; }
        public List<TeacherReadDTO> Teachers { get; set; } = new();
    }
}
