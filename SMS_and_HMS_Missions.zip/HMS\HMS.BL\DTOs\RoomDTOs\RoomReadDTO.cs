namespace HMS.BL.DTOs.RoomDTOs
{
    public class RoomReadDTO
    {
        public int Id { get; set; }
        public string RoomNumber { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
    }
}
