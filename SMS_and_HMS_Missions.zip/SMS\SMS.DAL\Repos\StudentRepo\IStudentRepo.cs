using SMS.DAL.Models;
using System.Collections.Generic;

namespace SMS.DAL.Repos.StudentRepo
{
    public interface IStudentRepo
    {
        void Add(Student student);
        Student? GetById(int id);
        IEnumerable<Student> GetAll();
        void Update(Student student);
        void Delete(Student student);
        bool SaveChanges();
    }
}
