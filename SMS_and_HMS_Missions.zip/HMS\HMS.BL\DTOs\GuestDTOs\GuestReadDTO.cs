using HMS.BL.DTOs.RoomDTOs;
using HMS.BL.DTOs.StaffDTOs;
using System.Collections.Generic;

namespace HMS.BL.DTOs.GuestDTOs
{
    public class GuestReadDTO
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public RoomReadDTO? Room { get; set; }
        public List<StaffReadDTO> StaffMembers { get; set; } = new();
    }
}
