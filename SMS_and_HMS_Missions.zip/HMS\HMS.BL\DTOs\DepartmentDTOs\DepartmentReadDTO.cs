namespace HMS.BL.DTOs.DepartmentDTOs
{
    public class DepartmentReadDTO
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
    }
}
