using SMS.DAL.Models;
using System.Collections.Generic;

namespace SMS.DAL.Repos.SubjectRepo
{
    public interface ISubjectRepo
    {
        void Add(Subject subject);
        Subject? GetById(int id);
        IEnumerable<Subject> GetAll();
        bool SaveChanges();
    }
}
