using HMS.DAL.Models;
using System.Collections.Generic;

namespace HMS.DAL.Repos.StaffRepo
{
    public interface IStaffRepo
    {
        void Add(Staff staff);
        Staff? GetById(int id);
        IEnumerable<Staff> GetAll();
        IEnumerable<Staff> GetByIds(IEnumerable<int> ids);
        bool SaveChanges();
    }
}
