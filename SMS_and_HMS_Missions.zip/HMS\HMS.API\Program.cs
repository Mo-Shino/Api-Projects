using Microsoft.EntityFrameworkCore;
using HMS.BL.Services.DepartmentService;
using HMS.BL.Services.GuestService;
using HMS.BL.Services.StaffService;
using HMS.DAL.Data;
using HMS.DAL.Repos.DepartmentRepo;
using HMS.DAL.Repos.GuestRepo;
using HMS.DAL.Repos.StaffRepo;

namespace HMS.API
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("conn")));

            builder.Services.AddScoped<IDepartmentRepo, DepartmentRepo>();
            builder.Services.AddScoped<IStaffRepo, StaffRepo>();
            builder.Services.AddScoped<IGuestRepo, GuestRepo>();

            builder.Services.AddScoped<IDepartmentService, DepartmentService>();
            builder.Services.AddScoped<IStaffService, StaffService>();
            builder.Services.AddScoped<IGuestService, GuestService>();

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}
