using SMS.BL.DTOs.TeacherDTOs;
using System.Collections.Generic;

namespace SMS.BL.Services.TeacherService
{
    public interface ITeacherService
    {
        TeacherReadDTO? Add(TeacherWriteDTO dto);
        TeacherReadDTO? GetById(int id);
        IEnumerable<TeacherReadDTO> GetAll();
    }
}
