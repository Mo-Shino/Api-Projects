using Microsoft.EntityFrameworkCore;
using HMS.DAL.Data;
using HMS.DAL.Models;
using System.Collections.Generic;
using System.Linq;

namespace HMS.DAL.Repos.StaffRepo
{
    public class StaffRepo : IStaffRepo
    {
        private readonly AppDbContext _context;

        public StaffRepo(AppDbContext context)
        {
            _context = context;
        }

        public void Add(Staff staff)
        {
            _context.Staff.Add(staff);
        }

        public Staff? GetById(int id)
        {
            return _context.Staff
                .Include(s => s.Department)
                .FirstOrDefault(s => s.Id == id);
        }

        public IEnumerable<Staff> GetAll()
        {
            return _context.Staff
                .Include(s => s.Department)
                .ToList();
        }

        public IEnumerable<Staff> GetByIds(IEnumerable<int> ids)
        {
            return _context.Staff
                .Include(s => s.Department)
                .Where(s => ids.Contains(s.Id))
                .ToList();
        }

        public bool SaveChanges()
        {
            return _context.SaveChanges() > 0;
        }
    }
}
