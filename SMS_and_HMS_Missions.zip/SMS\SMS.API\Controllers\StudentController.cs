using Microsoft.AspNetCore.Mvc;
using SMS.BL.DTOs.StudentDTOs;
using SMS.BL.Services.StudentService;

namespace SMS.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Route("api/students")]
    public class StudentController : ControllerBase
    {
        private readonly IStudentService _studentService;

        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        [HttpPost]
        public IActionResult Add([FromBody] StudentWriteDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = _studentService.Add(dto);
            return Ok(result);
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var students = _studentService.GetAll();
            return Ok(students);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var student = _studentService.GetById(id);
            if (student == null)
            {
                return NotFound($"Student with Id {id} not found.");
            }

            return Ok(student);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] StudentUpdateDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var updated = _studentService.Update(id, dto);
            if (!updated)
            {
                return NotFound($"Student with Id {id} not found.");
            }

            return Ok(new { message = "Student updated successfully." });
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var deleted = _studentService.Delete(id);
            if (!deleted)
            {
                return NotFound($"Student with Id {id} not found.");
            }

            return Ok(new { message = "Student deleted successfully." });
        }
    }
}
