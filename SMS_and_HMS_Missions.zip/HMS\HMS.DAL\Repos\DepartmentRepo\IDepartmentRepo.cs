using HMS.DAL.Models;
using System.Collections.Generic;

namespace HMS.DAL.Repos.DepartmentRepo
{
    public interface IDepartmentRepo
    {
        void Add(Department department);
        Department? GetById(int id);
        IEnumerable<Department> GetAll();
        bool SaveChanges();
    }
}
