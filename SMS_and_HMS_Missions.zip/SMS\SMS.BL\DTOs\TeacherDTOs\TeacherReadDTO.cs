namespace SMS.BL.DTOs.TeacherDTOs
{
    public class TeacherReadDTO
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string? Phone { get; set; }
        public int SubjectId { get; set; }
        public string? SubjectName { get; set; }
    }
}
