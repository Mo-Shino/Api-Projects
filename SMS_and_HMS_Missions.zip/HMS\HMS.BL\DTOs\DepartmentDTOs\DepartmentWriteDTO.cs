using System.ComponentModel.DataAnnotations;

namespace HMS.BL.DTOs.DepartmentDTOs
{
    public class DepartmentWriteDTO
    {
        [Required(ErrorMessage = "Department name is required")]
        [MaxLength(50, ErrorMessage = "Department name cannot exceed 50 characters")]
        public string Name { get; set; } = string.Empty;

        public string? Description { get; set; }
    }
}
