using HMS.BL.DTOs.StaffDTOs;
using System.Collections.Generic;

namespace HMS.BL.Services.StaffService
{
    public interface IStaffService
    {
        StaffReadDTO? Add(StaffWriteDTO dto);
        StaffReadDTO? GetById(int id);
        IEnumerable<StaffReadDTO> GetAll();
    }
}
