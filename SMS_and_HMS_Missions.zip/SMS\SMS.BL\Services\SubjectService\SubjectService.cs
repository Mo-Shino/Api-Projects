using SMS.BL.DTOs.SubjectDTOs;
using SMS.DAL.Models;
using SMS.DAL.Repos.SubjectRepo;
using System.Collections.Generic;
using System.Linq;

namespace SMS.BL.Services.SubjectService
{
    public class SubjectService : ISubjectService
    {
        private readonly ISubjectRepo _subjectRepo;

        public SubjectService(ISubjectRepo subjectRepo)
        {
            _subjectRepo = subjectRepo;
        }

        public SubjectReadDTO Add(SubjectWriteDTO dto)
        {
            var subject = new Subject
            {
                Name = dto.Name,
                Description = dto.Description
            };

            _subjectRepo.Add(subject);
            _subjectRepo.SaveChanges();

            return new SubjectReadDTO
            {
                Id = subject.Id,
                Name = subject.Name,
                Description = subject.Description
            };
        }

        public SubjectReadDTO? GetById(int id)
        {
            var subject = _subjectRepo.GetById(id);
            if (subject == null) return null;

            return new SubjectReadDTO
            {
                Id = subject.Id,
                Name = subject.Name,
                Description = subject.Description
            };
        }

        public IEnumerable<SubjectReadDTO> GetAll()
        {
            return _subjectRepo.GetAll().Select(s => new SubjectReadDTO
            {
                Id = s.Id,
                Name = s.Name,
                Description = s.Description
            }).ToList();
        }
    }
}
