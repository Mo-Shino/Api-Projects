using HMS.BL.DTOs.RoomDTOs;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HMS.BL.DTOs.GuestDTOs
{
    public class GuestWriteDTO
    {
        [Required(ErrorMessage = "Guest name is required")]
        [MaxLength(100, ErrorMessage = "Guest name cannot exceed 100 characters")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address format")]
        public string Email { get; set; } = string.Empty;

        public RoomWriteDTO? Room { get; set; }

        public string? RoomNumber { get; set; }

        public string? RoomType { get; set; }

        public List<int>? StaffIds { get; set; } = new();
    }
}
