using HMS.BL.DTOs.GuestDTOs;
using HMS.BL.DTOs.RoomDTOs;
using HMS.BL.DTOs.StaffDTOs;
using HMS.DAL.Models;
using HMS.DAL.Repos.GuestRepo;
using HMS.DAL.Repos.StaffRepo;
using System.Collections.Generic;
using System.Linq;

namespace HMS.BL.Services.GuestService
{
    public class GuestService : IGuestService
    {
        private readonly IGuestRepo _guestRepo;
        private readonly IStaffRepo _staffRepo;

        public GuestService(IGuestRepo guestRepo, IStaffRepo staffRepo)
        {
            _guestRepo = guestRepo;
            _staffRepo = staffRepo;
        }

        public GuestReadDTO Add(GuestWriteDTO dto)
        {
            var guest = new Guest
            {
                Name = dto.Name,
                Email = dto.Email
            };

            string? roomNumber = dto.Room?.RoomNumber ?? dto.RoomNumber;
            string? roomType = dto.Room?.Type ?? dto.RoomType;

            if (!string.IsNullOrWhiteSpace(roomNumber))
            {
                guest.Room = new Room
                {
                    RoomNumber = roomNumber.Trim(),
                    Type = string.IsNullOrWhiteSpace(roomType) ? "Standard" : roomType.Trim()
                };
            }

            if (dto.StaffIds != null && dto.StaffIds.Any())
            {
                var staffMembers = _staffRepo.GetByIds(dto.StaffIds);
                foreach (var staff in staffMembers)
                {
                    guest.StaffMembers.Add(staff);
                }
            }

            _guestRepo.Add(guest);
            _guestRepo.SaveChanges();

            return MapToReadDTO(guest);
        }

        public GuestReadDTO? GetById(int id)
        {
            var guest = _guestRepo.GetById(id);
            if (guest == null) return null;

            return MapToReadDTO(guest);
        }

        public IEnumerable<GuestReadDTO> GetAll()
        {
            return _guestRepo.GetAll().Select(MapToReadDTO).ToList();
        }

        public bool Update(int id, GuestUpdateDTO dto)
        {
            var guest = _guestRepo.GetById(id);
            if (guest == null) return false;

            guest.Name = dto.Name;
            guest.Email = dto.Email;

            string? roomNumber = dto.Room?.RoomNumber ?? dto.RoomNumber;
            string? roomType = dto.Room?.Type ?? dto.RoomType;

            if (!string.IsNullOrWhiteSpace(roomNumber))
            {
                if (guest.Room != null)
                {
                    guest.Room.RoomNumber = roomNumber.Trim();
                    if (!string.IsNullOrWhiteSpace(roomType))
                    {
                        guest.Room.Type = roomType.Trim();
                    }
                }
                else
                {
                    guest.Room = new Room
                    {
                        RoomNumber = roomNumber.Trim(),
                        Type = string.IsNullOrWhiteSpace(roomType) ? "Standard" : roomType.Trim()
                    };
                }
            }
            else if (dto.Room != null && string.IsNullOrWhiteSpace(dto.Room.RoomNumber))
            {
                guest.Room = null;
                guest.RoomId = null;
            }

            if (dto.StaffIds != null)
            {
                guest.StaffMembers.Clear();
                if (dto.StaffIds.Any())
                {
                    var staffMembers = _staffRepo.GetByIds(dto.StaffIds);
                    foreach (var staff in staffMembers)
                    {
                        guest.StaffMembers.Add(staff);
                    }
                }
            }

            _guestRepo.Update(guest);
            _guestRepo.SaveChanges();
            return true;
        }

        public bool Delete(int id)
        {
            var guest = _guestRepo.GetById(id);
            if (guest == null) return false;

            _guestRepo.Delete(guest);
            _guestRepo.SaveChanges();
            return true;
        }

        private static GuestReadDTO MapToReadDTO(Guest g)
        {
            return new GuestReadDTO
            {
                Id = g.Id,
                Name = g.Name,
                Email = g.Email,
                Room = g.Room == null ? null : new RoomReadDTO
                {
                    Id = g.Room.Id,
                    RoomNumber = g.Room.RoomNumber,
                    Type = g.Room.Type
                },
                StaffMembers = g.StaffMembers?.Select(s => new StaffReadDTO
                {
                    Id = s.Id,
                    Name = s.Name,
                    Email = s.Email,
                    Phone = s.Phone,
                    DepartmentId = s.DepartmentId,
                    DepartmentName = s.Department?.Name
                }).ToList() ?? new List<StaffReadDTO>()
            };
        }
    }
}
