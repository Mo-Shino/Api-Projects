using Microsoft.AspNetCore.Mvc;
using SMS.BL.DTOs.SubjectDTOs;
using SMS.BL.Services.SubjectService;

namespace SMS.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Route("api/subjects")]
    public class SubjectController : ControllerBase
    {
        private readonly ISubjectService _subjectService;

        public SubjectController(ISubjectService subjectService)
        {
            _subjectService = subjectService;
        }

        [HttpPost]
        public IActionResult Add([FromBody] SubjectWriteDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = _subjectService.Add(dto);
            return Ok(result);
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var subjects = _subjectService.GetAll();
            return Ok(subjects);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var subject = _subjectService.GetById(id);
            if (subject == null)
            {
                return NotFound($"Subject with Id {id} not found.");
            }

            return Ok(subject);
        }
    }
}
