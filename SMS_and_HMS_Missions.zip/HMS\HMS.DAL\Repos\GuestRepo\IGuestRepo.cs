using HMS.DAL.Models;
using System.Collections.Generic;

namespace HMS.DAL.Repos.GuestRepo
{
    public interface IGuestRepo
    {
        void Add(Guest guest);
        Guest? GetById(int id);
        IEnumerable<Guest> GetAll();
        void Update(Guest guest);
        void Delete(Guest guest);
        bool SaveChanges();
    }
}
