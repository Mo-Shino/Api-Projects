using HMS.BL.DTOs.GuestDTOs;
using System.Collections.Generic;

namespace HMS.BL.Services.GuestService
{
    public interface IGuestService
    {
        GuestReadDTO Add(GuestWriteDTO dto);
        GuestReadDTO? GetById(int id);
        IEnumerable<GuestReadDTO> GetAll();
        bool Update(int id, GuestUpdateDTO dto);
        bool Delete(int id);
    }
}
