using HMS.BL.DTOs.StaffDTOs;
using HMS.DAL.Models;
using HMS.DAL.Repos.DepartmentRepo;
using HMS.DAL.Repos.StaffRepo;
using System.Collections.Generic;
using System.Linq;

namespace HMS.BL.Services.StaffService
{
    public class StaffService : IStaffService
    {
        private readonly IStaffRepo _staffRepo;
        private readonly IDepartmentRepo _departmentRepo;

        public StaffService(IStaffRepo staffRepo, IDepartmentRepo departmentRepo)
        {
            _staffRepo = staffRepo;
            _departmentRepo = departmentRepo;
        }

        public StaffReadDTO? Add(StaffWriteDTO dto)
        {
            var department = _departmentRepo.GetById(dto.DepartmentId);
            if (department == null)
            {
                return null;
            }

            var staff = new Staff
            {
                Name = dto.Name,
                Email = dto.Email,
                Phone = dto.Phone,
                DepartmentId = dto.DepartmentId
            };

            _staffRepo.Add(staff);
            _staffRepo.SaveChanges();

            return new StaffReadDTO
            {
                Id = staff.Id,
                Name = staff.Name,
                Email = staff.Email,
                Phone = staff.Phone,
                DepartmentId = staff.DepartmentId,
                DepartmentName = department.Name
            };
        }

        public StaffReadDTO? GetById(int id)
        {
            var staff = _staffRepo.GetById(id);
            if (staff == null) return null;

            return new StaffReadDTO
            {
                Id = staff.Id,
                Name = staff.Name,
                Email = staff.Email,
                Phone = staff.Phone,
                DepartmentId = staff.DepartmentId,
                DepartmentName = staff.Department?.Name
            };
        }

        public IEnumerable<StaffReadDTO> GetAll()
        {
            return _staffRepo.GetAll().Select(s => new StaffReadDTO
            {
                Id = s.Id,
                Name = s.Name,
                Email = s.Email,
                Phone = s.Phone,
                DepartmentId = s.DepartmentId,
                DepartmentName = s.Department?.Name
            }).ToList();
        }
    }
}
