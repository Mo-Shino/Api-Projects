using SMS.BL.DTOs.StudentDTOs;
using System.Collections.Generic;

namespace SMS.BL.Services.StudentService
{
    public interface IStudentService
    {
        StudentReadDTO Add(StudentWriteDTO dto);
        StudentReadDTO? GetById(int id);
        IEnumerable<StudentReadDTO> GetAll();
        bool Update(int id, StudentUpdateDTO dto);
        bool Delete(int id);
    }
}
