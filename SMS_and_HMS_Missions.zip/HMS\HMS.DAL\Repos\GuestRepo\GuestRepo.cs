using Microsoft.EntityFrameworkCore;
using HMS.DAL.Data;
using HMS.DAL.Models;
using System.Collections.Generic;
using System.Linq;

namespace HMS.DAL.Repos.GuestRepo
{
    public class GuestRepo : IGuestRepo
    {
        private readonly AppDbContext _context;

        public GuestRepo(AppDbContext context)
        {
            _context = context;
        }

        public void Add(Guest guest)
        {
            _context.Guests.Add(guest);
        }

        public Guest? GetById(int id)
        {
            return _context.Guests
                .Include(g => g.Room)
                .Include(g => g.StaffMembers)
                    .ThenInclude(s => s.Department)
                .FirstOrDefault(g => g.Id == id);
        }

        public IEnumerable<Guest> GetAll()
        {
            return _context.Guests
                .Include(g => g.Room)
                .Include(g => g.StaffMembers)
                    .ThenInclude(s => s.Department)
                .ToList();
        }

        public void Update(Guest guest)
        {
            _context.Guests.Update(guest);
        }

        public void Delete(Guest guest)
        {
            if (guest.Room != null)
            {
                _context.Rooms.Remove(guest.Room);
            }
            _context.Guests.Remove(guest);
        }

        public bool SaveChanges()
        {
            return _context.SaveChanges() > 0;
        }
    }
}
