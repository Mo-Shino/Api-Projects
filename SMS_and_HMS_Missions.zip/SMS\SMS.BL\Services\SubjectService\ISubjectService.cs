using SMS.BL.DTOs.SubjectDTOs;
using System.Collections.Generic;

namespace SMS.BL.Services.SubjectService
{
    public interface ISubjectService
    {
        SubjectReadDTO Add(SubjectWriteDTO dto);
        SubjectReadDTO? GetById(int id);
        IEnumerable<SubjectReadDTO> GetAll();
    }
}
