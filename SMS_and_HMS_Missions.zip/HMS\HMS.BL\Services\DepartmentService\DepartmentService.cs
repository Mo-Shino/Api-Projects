using HMS.BL.DTOs.DepartmentDTOs;
using HMS.DAL.Models;
using HMS.DAL.Repos.DepartmentRepo;
using System.Collections.Generic;
using System.Linq;

namespace HMS.BL.Services.DepartmentService
{
    public class DepartmentService : IDepartmentService
    {
        private readonly IDepartmentRepo _departmentRepo;

        public DepartmentService(IDepartmentRepo departmentRepo)
        {
            _departmentRepo = departmentRepo;
        }

        public DepartmentReadDTO Add(DepartmentWriteDTO dto)
        {
            var department = new Department
            {
                Name = dto.Name,
                Description = dto.Description
            };

            _departmentRepo.Add(department);
            _departmentRepo.SaveChanges();

            return new DepartmentReadDTO
            {
                Id = department.Id,
                Name = department.Name,
                Description = department.Description
            };
        }

        public DepartmentReadDTO? GetById(int id)
        {
            var department = _departmentRepo.GetById(id);
            if (department == null) return null;

            return new DepartmentReadDTO
            {
                Id = department.Id,
                Name = department.Name,
                Description = department.Description
            };
        }

        public IEnumerable<DepartmentReadDTO> GetAll()
        {
            return _departmentRepo.GetAll().Select(d => new DepartmentReadDTO
            {
                Id = d.Id,
                Name = d.Name,
                Description = d.Description
            }).ToList();
        }
    }
}
