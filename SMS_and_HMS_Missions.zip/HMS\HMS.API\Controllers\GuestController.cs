using Microsoft.AspNetCore.Mvc;
using HMS.BL.DTOs.GuestDTOs;
using HMS.BL.Services.GuestService;

namespace HMS.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Route("api/guests")]
    public class GuestController : ControllerBase
    {
        private readonly IGuestService _guestService;

        public GuestController(IGuestService guestService)
        {
            _guestService = guestService;
        }

        [HttpPost]
        public IActionResult Add([FromBody] GuestWriteDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = _guestService.Add(dto);
            return Ok(result);
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var guests = _guestService.GetAll();
            return Ok(guests);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var guest = _guestService.GetById(id);
            if (guest == null)
            {
                return NotFound($"Guest with Id {id} not found.");
            }

            return Ok(guest);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] GuestUpdateDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var updated = _guestService.Update(id, dto);
            if (!updated)
            {
                return NotFound($"Guest with Id {id} not found.");
            }

            return Ok(new { message = "Guest updated successfully." });
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var deleted = _guestService.Delete(id);
            if (!deleted)
            {
                return NotFound($"Guest with Id {id} not found.");
            }

            return Ok(new { message = "Guest deleted successfully." });
        }
    }
}
