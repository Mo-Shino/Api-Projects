using Microsoft.EntityFrameworkCore;
using SMS.DAL.Data;
using SMS.DAL.Models;
using System.Collections.Generic;
using System.Linq;

namespace SMS.DAL.Repos.TeacherRepo
{
    public class TeacherRepo : ITeacherRepo
    {
        private readonly AppDbContext _context;

        public TeacherRepo(AppDbContext context)
        {
            _context = context;
        }

        public void Add(Teacher teacher)
        {
            _context.Teachers.Add(teacher);
        }

        public Teacher? GetById(int id)
        {
            return _context.Teachers
                .Include(t => t.Subject)
                .FirstOrDefault(t => t.Id == id);
        }

        public IEnumerable<Teacher> GetAll()
        {
            return _context.Teachers
                .Include(t => t.Subject)
                .ToList();
        }

        public IEnumerable<Teacher> GetByIds(IEnumerable<int> ids)
        {
            return _context.Teachers
                .Include(t => t.Subject)
                .Where(t => ids.Contains(t.Id))
                .ToList();
        }

        public bool SaveChanges()
        {
            return _context.SaveChanges() > 0;
        }
    }
}
