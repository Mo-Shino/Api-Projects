using Microsoft.EntityFrameworkCore;
using SMS.DAL.Data;
using SMS.DAL.Models;
using System.Collections.Generic;
using System.Linq;

namespace SMS.DAL.Repos.StudentRepo
{
    public class StudentRepo : IStudentRepo
    {
        private readonly AppDbContext _context;

        public StudentRepo(AppDbContext context)
        {
            _context = context;
        }

        public void Add(Student student)
        {
            _context.Students.Add(student);
        }

        public Student? GetById(int id)
        {
            return _context.Students
                .Include(s => s.Laptop)
                .Include(s => s.Teachers)
                    .ThenInclude(t => t.Subject)
                .FirstOrDefault(s => s.Id == id);
        }

        public IEnumerable<Student> GetAll()
        {
            return _context.Students
                .Include(s => s.Laptop)
                .Include(s => s.Teachers)
                    .ThenInclude(t => t.Subject)
                .ToList();
        }

        public void Update(Student student)
        {
            _context.Students.Update(student);
        }

        public void Delete(Student student)
        {
            if (student.Laptop != null)
            {
                _context.Laptops.Remove(student.Laptop);
            }
            _context.Students.Remove(student);
        }

        public bool SaveChanges()
        {
            return _context.SaveChanges() > 0;
        }
    }
}
