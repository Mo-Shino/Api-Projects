using System.ComponentModel.DataAnnotations;

namespace SMS.BL.DTOs.TeacherDTOs
{
    public class TeacherWriteDTO
    {
        [Required(ErrorMessage = "Teacher name is required")]
        [MaxLength(100, ErrorMessage = "Teacher name cannot exceed 100 characters")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address format")]
        public string Email { get; set; } = string.Empty;

        public string? Phone { get; set; }

        [Required(ErrorMessage = "SubjectId is required")]
        public int SubjectId { get; set; }
    }
}
