using Microsoft.AspNetCore.Mvc;
using SMS.BL.DTOs.TeacherDTOs;
using SMS.BL.Services.TeacherService;

namespace SMS.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Route("api/teachers")]
    public class TeacherController : ControllerBase
    {
        private readonly ITeacherService _teacherService;

        public TeacherController(ITeacherService teacherService)
        {
            _teacherService = teacherService;
        }

        [HttpPost]
        public IActionResult Add([FromBody] TeacherWriteDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = _teacherService.Add(dto);
            if (result == null)
            {
                return BadRequest($"Subject with Id {dto.SubjectId} does not exist.");
            }

            return Ok(result);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var teacher = _teacherService.GetById(id);
            if (teacher == null)
            {
                return NotFound($"Teacher with Id {id} not found.");
            }

            return Ok(teacher);
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var teachers = _teacherService.GetAll();
            return Ok(teachers);
        }
    }
}
