using System.ComponentModel.DataAnnotations;

namespace HMS.BL.DTOs.StaffDTOs
{
    public class StaffWriteDTO
    {
        [Required(ErrorMessage = "Staff name is required")]
        [MaxLength(100, ErrorMessage = "Staff name cannot exceed 100 characters")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address format")]
        public string Email { get; set; } = string.Empty;

        public string? Phone { get; set; }

        [Required(ErrorMessage = "DepartmentId is required")]
        public int DepartmentId { get; set; }
    }
}
