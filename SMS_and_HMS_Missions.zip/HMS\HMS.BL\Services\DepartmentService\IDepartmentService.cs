using HMS.BL.DTOs.DepartmentDTOs;
using System.Collections.Generic;

namespace HMS.BL.Services.DepartmentService
{
    public interface IDepartmentService
    {
        DepartmentReadDTO Add(DepartmentWriteDTO dto);
        DepartmentReadDTO? GetById(int id);
        IEnumerable<DepartmentReadDTO> GetAll();
    }
}
