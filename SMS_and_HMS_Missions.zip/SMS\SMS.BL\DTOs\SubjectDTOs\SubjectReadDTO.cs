namespace SMS.BL.DTOs.SubjectDTOs
{
    public class SubjectReadDTO
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
    }
}
